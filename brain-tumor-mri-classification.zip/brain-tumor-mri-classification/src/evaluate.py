"""Evaluation script for multiclass brain tumor MRI classification."""

import argparse
from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import tensorflow as tf
from sklearn.metrics import accuracy_score, classification_report, confusion_matrix, f1_score, precision_score, recall_score


def main():
    parser = argparse.ArgumentParser(description="Evaluate a trained brain tumor MRI classification model.")
    parser.add_argument("--data_dir", type=str, required=True, help="Dataset root containing test folder.")
    parser.add_argument("--model_path", type=str, required=True, help="Path to saved .keras model.")
    parser.add_argument("--batch_size", type=int, default=32)
    parser.add_argument("--img_size", type=int, default=150)
    args = parser.parse_args()

    test_dir = Path(args.data_dir) / "test"
    if not test_dir.exists():
        raise FileNotFoundError(f"Test folder not found: {test_dir}")

    test_ds = tf.keras.utils.image_dataset_from_directory(
        test_dir,
        labels="inferred",
        label_mode="categorical",
        image_size=(args.img_size, args.img_size),
        batch_size=args.batch_size,
        shuffle=False,
    )
    class_names = test_ds.class_names

    normalization = tf.keras.layers.Rescaling(1.0 / 255)
    test_ds_norm = test_ds.map(lambda x, y: (normalization(x), y)).prefetch(tf.data.AUTOTUNE)

    model = tf.keras.models.load_model(args.model_path)
    probabilities = model.predict(test_ds_norm)
    y_pred = np.argmax(probabilities, axis=1)
    y_true = np.concatenate([np.argmax(y.numpy(), axis=1) for _, y in test_ds], axis=0)

    acc = accuracy_score(y_true, y_pred)
    macro_precision = precision_score(y_true, y_pred, average="macro", zero_division=0)
    macro_recall = recall_score(y_true, y_pred, average="macro", zero_division=0)
    macro_f1 = f1_score(y_true, y_pred, average="macro", zero_division=0)

    print(f"Accuracy: {acc:.4f}")
    print(f"Macro precision: {macro_precision:.4f}")
    print(f"Macro recall: {macro_recall:.4f}")
    print(f"Macro F1-score: {macro_f1:.4f}")
    print("\nClassification report:")
    print(classification_report(y_true, y_pred, target_names=class_names, zero_division=0))

    cm = confusion_matrix(y_true, y_pred)
    results_dir = Path("results")
    results_dir.mkdir(exist_ok=True)

    pd.DataFrame(cm, index=class_names, columns=class_names).to_csv(results_dir / "confusion_matrix.csv")

    plt.figure(figsize=(7, 6))
    plt.imshow(cm)
    plt.title("Confusion Matrix")
    plt.xlabel("Predicted class")
    plt.ylabel("True class")
    plt.xticks(range(len(class_names)), class_names, rotation=45, ha="right")
    plt.yticks(range(len(class_names)), class_names)
    for i in range(cm.shape[0]):
        for j in range(cm.shape[1]):
            plt.text(j, i, str(cm[i, j]), ha="center", va="center")
    plt.tight_layout()
    plt.savefig(results_dir / "confusion_matrix.png", dpi=300)
    print("Saved confusion matrix outputs in results/.")


if __name__ == "__main__":
    main()
