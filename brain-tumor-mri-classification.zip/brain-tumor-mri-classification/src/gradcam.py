"""Minimal Grad-CAM utility for trained Keras CNN models."""

import argparse
from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np
import tensorflow as tf


def make_gradcam_heatmap(img_array, model, last_conv_layer_name, pred_index=None):
    grad_model = tf.keras.models.Model(
        [model.inputs],
        [model.get_layer(last_conv_layer_name).output, model.output],
    )

    with tf.GradientTape() as tape:
        conv_outputs, predictions = grad_model(img_array)
        if pred_index is None:
            pred_index = tf.argmax(predictions[0])
        class_channel = predictions[:, pred_index]

    grads = tape.gradient(class_channel, conv_outputs)
    pooled_grads = tf.reduce_mean(grads, axis=(0, 1, 2))
    conv_outputs = conv_outputs[0]
    heatmap = conv_outputs @ pooled_grads[..., tf.newaxis]
    heatmap = tf.squeeze(heatmap)
    heatmap = tf.maximum(heatmap, 0) / tf.math.reduce_max(heatmap)
    return heatmap.numpy()


def main():
    parser = argparse.ArgumentParser(description="Generate Grad-CAM heatmap for a single MRI image.")
    parser.add_argument("--model_path", required=True)
    parser.add_argument("--image_path", required=True)
    parser.add_argument("--last_conv_layer", required=True, help="Name of the final convolutional layer.")
    parser.add_argument("--img_size", type=int, default=150)
    args = parser.parse_args()

    model = tf.keras.models.load_model(args.model_path)
    img = tf.keras.utils.load_img(args.image_path, target_size=(args.img_size, args.img_size))
    arr = tf.keras.utils.img_to_array(img)
    arr = np.expand_dims(arr / 255.0, axis=0)

    heatmap = make_gradcam_heatmap(arr, model, args.last_conv_layer)

    Path("results").mkdir(exist_ok=True)
    plt.figure(figsize=(5, 5))
    plt.imshow(heatmap)
    plt.axis("off")
    plt.tight_layout()
    plt.savefig("results/gradcam_heatmap.png", dpi=300)
    print("Saved Grad-CAM heatmap to results/gradcam_heatmap.png")


if __name__ == "__main__":
    main()
