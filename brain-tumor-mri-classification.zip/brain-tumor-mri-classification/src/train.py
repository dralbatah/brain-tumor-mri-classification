"""Training script for multiclass brain tumor MRI classification."""

import argparse
import os
import random
from pathlib import Path

import numpy as np
import tensorflow as tf
from tensorflow.keras import layers, models
from tensorflow.keras.applications import DenseNet121, ResNet101, Xception, EfficientNetB0
from tensorflow.keras.callbacks import EarlyStopping, ModelCheckpoint, ReduceLROnPlateau


def set_seed(seed: int) -> None:
    random.seed(seed)
    np.random.seed(seed)
    tf.random.set_seed(seed)
    os.environ["PYTHONHASHSEED"] = str(seed)


def get_backbone(model_name: str, img_size: int):
    input_shape = (img_size, img_size, 3)
    model_map = {
        "DenseNet121": DenseNet121,
        "ResNet101": ResNet101,
        "Xception": Xception,
        "EfficientNetB0": EfficientNetB0,
    }
    if model_name not in model_map:
        raise ValueError(f"Unsupported model: {model_name}. Choose from {list(model_map.keys())}")
    return model_map[model_name](
        include_top=False,
        weights="imagenet",
        input_shape=input_shape,
    )


def build_model(model_name: str, img_size: int, num_classes: int, learning_rate: float):
    backbone = get_backbone(model_name, img_size)
    backbone.trainable = False

    inputs = layers.Input(shape=(img_size, img_size, 3))
    x = backbone(inputs, training=False)
    x = layers.GlobalAveragePooling2D()(x)
    x = layers.Dropout(0.3)(x)
    outputs = layers.Dense(num_classes, activation="softmax")(x)

    model = models.Model(inputs, outputs, name=model_name)
    model.compile(
        optimizer=tf.keras.optimizers.Adam(learning_rate=learning_rate),
        loss="categorical_crossentropy",
        metrics=["accuracy"],
    )
    return model


def main():
    parser = argparse.ArgumentParser(description="Train transfer-learning models for brain tumor MRI classification.")
    parser.add_argument("--data_dir", type=str, required=True, help="Dataset root containing train and test folders.")
    parser.add_argument("--model", type=str, default="EfficientNetB0", choices=["DenseNet121", "ResNet101", "Xception", "EfficientNetB0"])
    parser.add_argument("--epochs", type=int, default=30)
    parser.add_argument("--batch_size", type=int, default=32)
    parser.add_argument("--img_size", type=int, default=150)
    parser.add_argument("--learning_rate", type=float, default=1e-4)
    parser.add_argument("--seed", type=int, default=42)
    args = parser.parse_args()

    set_seed(args.seed)

    data_root = Path(args.data_dir)
    train_dir = data_root / "train"
    if not train_dir.exists():
        raise FileNotFoundError(f"Training folder not found: {train_dir}")

    train_ds = tf.keras.utils.image_dataset_from_directory(
        train_dir,
        labels="inferred",
        label_mode="categorical",
        image_size=(args.img_size, args.img_size),
        batch_size=args.batch_size,
        validation_split=0.2,
        subset="training",
        seed=args.seed,
    )

    val_ds = tf.keras.utils.image_dataset_from_directory(
        train_dir,
        labels="inferred",
        label_mode="categorical",
        image_size=(args.img_size, args.img_size),
        batch_size=args.batch_size,
        validation_split=0.2,
        subset="validation",
        seed=args.seed,
    )

    class_names = train_ds.class_names
    num_classes = len(class_names)
    print("Class names:", class_names)

    normalization = layers.Rescaling(1.0 / 255)
    augmentation = tf.keras.Sequential([
        layers.RandomFlip("horizontal"),
        layers.RandomRotation(0.10),
        layers.RandomZoom(0.10),
        layers.RandomContrast(0.10),
    ])

    autotune = tf.data.AUTOTUNE
    train_ds = train_ds.map(lambda x, y: (augmentation(normalization(x), training=True), y)).prefetch(autotune)
    val_ds = val_ds.map(lambda x, y: (normalization(x), y)).prefetch(autotune)

    model = build_model(args.model, args.img_size, num_classes, args.learning_rate)
    model.summary()

    results_dir = Path("results")
    results_dir.mkdir(exist_ok=True)
    model_path = results_dir / f"{args.model}_best.keras"

    callbacks = [
        EarlyStopping(monitor="val_loss", patience=8, restore_best_weights=True),
        ModelCheckpoint(filepath=str(model_path), monitor="val_accuracy", save_best_only=True),
        ReduceLROnPlateau(monitor="val_loss", factor=0.2, patience=4, min_lr=1e-7),
    ]

    history = model.fit(train_ds, validation_data=val_ds, epochs=args.epochs, callbacks=callbacks)
    model.save(results_dir / f"{args.model}_final.keras")

    print(f"Best model saved to: {model_path}")


if __name__ == "__main__":
    main()
