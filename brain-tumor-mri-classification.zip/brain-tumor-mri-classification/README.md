# Brain Tumor MRI Classification

This repository contains reproducibility code for the manuscript:

**Comparative and Explainable Deep Learning Framework for Multiclass Brain Tumor Classification from MRI Images**

The project trains and evaluates four transfer-learning architectures for multiclass brain tumor MRI classification:

- DenseNet121
- ResNet101
- Xception
- EfficientNetB0

## Dataset

The dataset used in the manuscript is publicly available on Kaggle:

https://www.kaggle.com/datasets/mohamadabouali1/mri-brain-tumor-dataset-4-class-7023-images

Expected class folders:

- `glioma`
- `meningioma`
- `pituitary`
- `notumor` or `no_tumor`

Download the dataset from Kaggle and organize it as follows:

```text
data/
  train/
    glioma/
    meningioma/
    pituitary/
    notumor/
  test/
    glioma/
    meningioma/
    pituitary/
    notumor/
```

If the downloaded dataset uses different folder names, rename them or edit the class names in the scripts.

## Environment

Python 3.9 or higher is recommended.

Install the required packages:

```bash
pip install -r requirements.txt
```

## Training

Example training command:

```bash
python src/train.py --data_dir data --model EfficientNetB0 --epochs 30 --batch_size 32 --img_size 150
```

Supported models:

```text
DenseNet121, ResNet101, Xception, EfficientNetB0
```

## Evaluation

After training, evaluate the saved model:

```bash
python src/evaluate.py --data_dir data --model_path results/EfficientNetB0_best.keras --img_size 150
```

The evaluation script generates:

- classification report
- confusion matrix
- accuracy
- macro precision
- macro recall
- macro F1-score

## Reproducibility Notes

The manuscript reports results based on available test-set confusion matrices and an extended diagnostic analysis. Exact results may vary depending on dataset split, random seed, GPU/CPU backend, TensorFlow/Keras version, and preprocessing settings.

For strict reproducibility, use the same dataset split, image size, preprocessing configuration, and random seed reported in the manuscript.

## Citation

Please cite the manuscript if you use this code or dataset workflow.
